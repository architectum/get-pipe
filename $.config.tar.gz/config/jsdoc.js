'use strict';

module.exports = {
  recurseDepth: 50,
  plugins: [
    'plugins/markdown'
  ],
  source: {
    exclude: ['./config', './docs', './node_modules']
  },
  opts: {
    destination: 'docs/code',
    template: 'node_modules/postman-jsdoc-theme',
    recurse: true,
    encoding: 'utf8',
  },
  templates: {
    cleverLinks: true,
  },
};
