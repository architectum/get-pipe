'use strict';

const config = require('config');
const { readFileSync } = require('fs');
const { resolve } = require('path');

module.exports = {
  ...config,
  tokenization: {
    ...config.tokenization,
    public: readFileSync(resolve(config.tokenization.public)),
    private: readFileSync(resolve(config.tokenization.private)),
  },
};
