'use strict';
/* eslint camelcase: "off" */

module.exports = {
  apps: [{
    name: 'Appotek Central',
    script: './bin/server.js',
    kill_timeout: 300000,
    wait_ready: true,
    listen_timeout: 30000,
    exec_mode: 'cluster',
    instances: 'max',
    port: 3001,
    output: '/dev/null',
    error: '/dev/null',
    env: {
      NODE_ENV: 'development',
    },
    env_production: {
      NODE_ENV: 'production',
    }
  }]
};
