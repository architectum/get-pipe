require('dotenv').config()

module.exports = {
  production: {
    host: process.env.DB_CENTRAL_HOST,
    database: process.env.DB_CENTRAL_DATABASE,
    username: process.env.DB_CENTRAL_USER,
    password: process.env.DB_CENTRAL_PASSWORD,
    dialect: 'postgres',
    seederStorage: 'sequelize'
  },
  development: {
    host: process.env.DB_CENTRAL_HOST,
    database: process.env.DB_CENTRAL_DATABASE,
    username: process.env.DB_CENTRAL_USER,
    password: process.env.DB_CENTRAL_PASSWORD,
    dialect: 'postgres',
    seederStorage: 'sequelize'
  },
  test: {
    host: process.env.DB_CENTRAL_HOST,
    database: process.env.DB_CENTRAL_DATABASE,
    username: process.env.DB_CENTRAL_USER,
    password: process.env.DB_CENTRAL_PASSWORD,
    dialect: 'postgres',
    seederStorage: 'sequelize'
  },
};
